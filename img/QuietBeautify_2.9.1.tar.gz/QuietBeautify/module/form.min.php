<?php
class QuietinputHead{
    
     static function mouseStyle(){
		// 插件所在位置的路径信息
		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/';
        $dir = $PluginPath . 'assets/img';
		
		$list = [
		    '0' => _t('关闭'),
		    '1' => "<img src='{$dir}/normal.cur'>",
		    '2' => "<img src='{$dir}/a1.cur'>",
		    '3' => "<img src='{$dir}/b1.cur'>",
		    '4' => "<img src='{$dir}/c1.cur'>",
		    '5' => "<img src='{$dir}/d1.cur'>",
		    '6' => "<img src='{$dir}/e.cur'>",
		    '7' => "<img src='{$dir}/f.cur'>",
		    '8' => "<img src='{$dir}/g.cur'>",
		];
	
		$result = new Typecho_Widget_Helper_Form_Element_Radio('pointerStyle', $list, 0, '鼠标指针', '自己选嘛');
		return $result;
	}
	
	static function msqpost(){

	
    
	}
    	static function updata($Cver){
	    
	    // 获取API信息
		$ch = curl_init("https://api.txmmp.cn/api/blogUpdata.php");
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		
		$res = curl_exec($ch);
		
		$data = json_decode($res,JSON_UNESCAPED_UNICODE);
		
		if($data['status'] == 1){
		    
		    $Sver = $data['version'];
		    
		    if($Cver != $Sver){
		        
		        $info = '<div class="container"><div class="inner"><span></span><h1>'. $data['title'] .'</h1><p>下载地址：<a href="'. $data['url'] .'">'. $data['url'] .'</a></p></div></div>';
		        return $info;
		    }
		    
		    return $info;
		    
		}else{
		    
		    echo '无法获取插件更新信息！';
		}
	} 
		static function right(){
           $mouselist = [
			'yj'      => '屏蔽右键',
			'pbf12'      => '屏蔽F12'
	    ];
	    $mouse_list = [
			// 'Particles',
		];
            $mouse_config=new Typecho_Widget_Helper_Form_Element_Checkbox(
                'mouse_config',
                $mouselist,
                $mouse_list,
                '是否屏蔽右键/F12:',
                '屏蔽鼠标右键/F12'
            );
            $mouse_config->setAttribute('class', 'j-setting-content j-setting-general');
 return $mouse_config;
	    
	}
	   static function collapse(){
                    $collapse = new Typecho_Widget_Helper_Form_Element_Radio(
            'collapse',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('是否开启崩溃欺骗'),
            _t('芜湖芜湖芜湖~~</br>')
        );
        $collapse->setAttribute('class', 'j-setting-content j-setting-general');
       return $collapse;
    }
    	   static function hangcat(){
                    $hangcat = new Typecho_Widget_Helper_Form_Element_Radio(
            'hangcat',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('是否开启悬挂猫'),
            _t('返回顶部的一个猫咪</br>')
        );
        $hangcat->setAttribute('class', 'j-setting-content j-setting-general');
       return $hangcat;
    }
      static function copyi(){
                    $copyi = new Typecho_Widget_Helper_Form_Element_Radio(
            'copyi',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('是否开启复制提醒'),
            _t('复制内容后提醒保留版权</br>')
        );
        $copyi->setAttribute('class', 'j-setting-content j-setting-general');
       return $copyi;
    }
          static function typewriting(){
                    $typewriting = new Typecho_Widget_Helper_Form_Element_Radio(
            'typewriting',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('是否开启打字特效'),
            _t('开启打字特效</br>')
        );
        $typewriting->setAttribute('class', 'j-setting-content j-setting-general');
       return $typewriting;
    }
    		static function linkcss(){
           $linklist = [
			'query'      => '加载jquery',
			'font'      => '加载font-awesome',
			'layui'      => '加载layui',
			'animate' => '加载animate动画'
	    ];
	    $link_list = [
			// 'Particles',
		];
            $link_config=new Typecho_Widget_Helper_Form_Element_Checkbox(
                'link_config',
                $linklist,
                $link_list,
                '是否引入以下库:',
                '快捷引入第三方库'
            );
            $link_config->setAttribute('class', 'j-setting-content j-setting-general');
 return $link_config;
	    
	}
	// 	loading动画
     static function loadinglist(){
		// 插件所在位置的路径信息
		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/';
		
		$list = [
		    '0' => _t('关闭'),
		    '1' => "黑圈圈",
		    '3' => "样式1",
		    '4' => "样式2",
		    '5' => "样式3",
		    '6' => "样式4",
		    '7' => "样式5",
		    '8' => "样式6",
		    '9' => "样式7",
		    '10' => "样式8",
		    '11' => "样式9",
		    '12' => "样式10",
		    '13' => "样式11",
		    '14' => "样式12",
		    '15' => "样式13",
		    '16' => "样式14",
		    '17' => "样式15",
		    '18' => "彩色圈圈",
		];
	
		$result = new Typecho_Widget_Helper_Form_Element_Select('loadingStyle', $list, 0, '页面加载动画', '自己选嘛');
		return $result->setAttribute('class', 'j-setting-content j-setting-general');
	}
// 	右下角图标
     static function righticon(){
		// 插件所在位置的路径信息
		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/';
		
		$list = [
		    '0' => _t('关闭'),
		    '1' => _t('开启'),
		];
	
		$result = new Typecho_Widget_Helper_Form_Element_Radio('righticon', $list, 0, '右下角认证图标', '在页面右下角添加一个认证的图标');
		return $result->setAttribute('class', 'j-setting-content j-setting-general');
	}
// 	彩色加载条
	     static function progress(){
		// 插件所在位置的路径信息
		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/';
		
		$list = [
		    '0' => _t('关闭'),
		    '1' => _t('开启'),
		];
	
		$result = new Typecho_Widget_Helper_Form_Element_Radio('loadingprogress', $list, 0, '顶部彩色加载条', '在页面顶部添加一个彩色的加载条');
		return $result->setAttribute('class', 'j-setting-content j-setting-general');
	}
		     static function cstext(){
		// 插件所在位置的路径信息
		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/';
		$result = new Typecho_Widget_Helper_Form_Element_Text('cstext', NULL, NULL, '循环闪耀彩色文字', '让一个文字循环变色,请使用css选择器，请按照css样式class名或者id名输入，如.nav #header div.content等');
		return $result->setAttribute('class', 'j-setting-content j-setting-general');
	}
// 	鼠标点击特效
     static function clickstyle(){
		// 插件所在位置的路径信息
		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/';
		
		$list = [
		    '0' => _t('关闭'),
		    '1' => "样式1",
		    '2' => "样式2",
		    '3' => "样式3",
		    '4' => "样式4",
		    '5' => "样式5",
		    '6' => "样式6",
		    '7' => "样式7",
		    '8' => "样式8",
		    '9' => "样式9",
		    '10' => "样式10",
		    '11' => "样式11"
		];
	
		$result = new Typecho_Widget_Helper_Form_Element_Select('clickstyle', $list, 0, '鼠标点击特效', '自己选嘛');
		return $result->setAttribute('class', 'j-setting-content j-setting-general');
	}
	static function send(){
	    
          $result = new Typecho_Widget_Helper_Form_Element_Text('send', NULL, NULL, '评论通知', '对接Qmsg推送,自行https://qmsg.zendee.cn/注册,填写好key即可');
		return $result->setAttribute('class', 'j-setting-content j-setting-general');
          
    }
    // wow
     static function wow(){
		// 插件所在位置的路径信息
		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/';
		$result = new Typecho_Widget_Helper_Form_Element_Text('wow', NULL, NULL, '动态加载', '需要加载animate.css,请在顶部引入,请使用css选择器，请按照css样式class名或者id名输入，如.nav #header div.content等');
		return $result->setAttribute('class', 'j-setting-content j-setting-general');
	}
	     static function wowlist(){
		// 插件所在位置的路径信息
		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/';
		$result = new Typecho_Widget_Helper_Form_Element_Select('wowlist', array(
            'off' => '关闭（默认）',
            'bounce' => 'bounce',
            'flash' => 'flash',
            'pulse' => 'pulse',
            'rubberBand' => 'rubberBand',
            'headShake' => 'headShake',
            'swing' => 'swing',
            'tada' => 'tada',
            'wobble' => 'wobble',
            'jello' => 'jello',
            'heartBeat' => 'heartBeat',
            'bounceIn' => 'bounceIn',
            'bounceInDown' => 'bounceInDown',
            'bounceInLeft' => 'bounceInLeft',
            'bounceInRight' => 'bounceInRight',
            'bounceInUp' => 'bounceInUp',
            'bounceOut' => 'bounceOut',
            'bounceOutDown' => 'bounceOutDown',
            'bounceOutLeft' => 'bounceOutLeft',
            'bounceOutRight' => 'bounceOutRight',
            'bounceOutUp' => 'bounceOutUp',
            'fadeIn' => 'fadeIn',
            'fadeInDown' => 'fadeInDown',
            'fadeInDownBig' => 'fadeInDownBig',
            'fadeInLeft' => 'fadeInLeft',
            'fadeInLeftBig' => 'fadeInLeftBig',
            'fadeInRight' => 'fadeInRight',
            'fadeInRightBig' => 'fadeInRightBig',
            'fadeInUp' => 'fadeInUp',
            'fadeInUpBig' => 'fadeInUpBig',
            'fadeOut' => 'fadeOut',
            'fadeOutDown' => 'fadeOutDown',
            'fadeOutDownBig' => 'fadeOutDownBig',
            'fadeOutLeft' => 'fadeOutLeft',
            'fadeOutLeftBig' => 'fadeOutLeftBig',
            'fadeOutRight' => 'fadeOutRight',
            'fadeOutRightBig' => 'fadeOutRightBig',
            'fadeOutUp' => 'fadeOutUp',
            'fadeOutUpBig' => 'fadeOutUpBig',
            'flip' => 'flip',
            'flipInX' => 'flipInX',
            'flipInY' => 'flipInY',
            'flipOutX' => 'flipOutX',
            'flipOutY' => 'flipOutY',
            'rotateIn' => 'rotateIn',
            'rotateInDownLeft' => 'rotateInDownLeft',
            'rotateInDownRight' => 'rotateInDownRight',
            'rotateInUpLeft' => 'rotateInUpLeft',
            'rotateInUpRight' => 'rotateInUpRight',
            'rotateOut' => 'rotateOut',
            'rotateOutDownLeft' => 'rotateOutDownLeft',
            'rotateOutDownRight' => 'rotateOutDownRight',
            'rotateOutUpLeft' => 'rotateOutUpLeft',
            'rotateOutUpRight' => 'rotateOutUpRight',
            'hinge' => 'hinge',
            'jackInTheBox' => 'jackInTheBox',
            'rollIn' => 'rollIn',
            'rollOut' => 'rollOut',
            'zoomIn' => 'zoomIn',
            'zoomInDown' => 'zoomInDown',
            'zoomInLeft' => 'zoomInLeft',
            'zoomInRight' => 'zoomInRight',
            'zoomInUp' => 'zoomInUp',
            'zoomOut' => 'zoomOut',
            'zoomOutDown' => 'zoomOutDown',
            'zoomOutLeft' => 'zoomOutLeft',
            'zoomOutRight' => 'zoomOutRight',
            'zoomOutUp' => 'zoomOutUp',
            'slideInDown' => 'slideInDown',
            'slideInLeft' => 'slideInLeft',
            'slideInRight' => 'slideInRight',
            'slideInUp' => 'slideInUp',
            'slideOutDown' => 'slideOutDown',
            'slideOutLeft' => 'slideOutLeft',
            'slideOutRight' => 'slideOutRight',
            'slideOutUp' => 'slideOutUp',
        ),
        'off', '动态加载效果','需要加载animate.css,请在顶部引入,请选择需要的效果');
		return $result->setAttribute('class', 'j-setting-content j-setting-general');
	}
 }
    
    
    
?>