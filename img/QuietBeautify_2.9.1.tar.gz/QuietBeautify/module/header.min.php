<?php


 
class Quietheader{
  
    static function loadingTrans (){
        		$type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->loadingStyle;
        		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/assets/css/loader.css';
        		if($type==0){
        		}
        		if($type==1){
        		    	      echo <<<HTML
        	<style>#PageLoading{background-color:#fff;height:100%;width:100%;position:fixed;z-index:1;margin-top:0px;top:0px;}#PageLoading-center{width:100%;height:100%;position:relative;}#PageLoading-center-absolute{position:absolute;left:50%;top:50%;height:200px;width:200px;margin-top:-100px;margin-left:-100px;}.object{-moz-border-radius:50% 50% 50% 50%;-webkit-border-radius:50% 50% 50% 50%;border-radius:50% 50% 50% 50%;position:absolute;border-left:5px solid #000;border-right:5px solid #000;border-top:5px solid transparent;border-bottom:5px solid transparent;-webkit-animation:animate 2s infinite;animation:animate 2s infinite;}#object_one{left:75px;top:75px;width:50px;height:50px;}#object_two{left:65px;top:65px;width:70px;height:70px;-webkit-animation-delay:0.1s;animation-delay:0.1s;}#object_three{left:55px;top:55px;width:90px;height:90px;-webkit-animation-delay:0.2s;animation-delay:0.2s;}#object_four{left:45px;top:45px;width:110px;height:110px;-webkit-animation-delay:0.3s;animation-delay:0.3s;}@-webkit-keyframes animate{50%{-ms-transform:rotate(180deg);-webkit-transform:rotate(180deg);transform:rotate(180deg);}100%{-ms-transform:rotate(0deg);-webkit-transform:rotate(0deg);transform:rotate(0deg);}}@keyframes animate{50%{-ms-transform:rotate(180deg);-webkit-transform:rotate(180deg);transform:rotate(180deg);}100%{-ms-transform:rotate(0deg);-webkit-transform:rotate(0deg);transform:rotate(0deg);}}</style>
 <div id="PageLoading" style="z-index:999999;">
    	<div id="PageLoading-center">
    		<div id="PageLoading-center-absolute">
    			<div class="object" id="object_four"></div>
    			<div class="object" id="object_three"></div>
    			<div class="object" id="object_two"></div>
    			<div class="object" id="object_one"></div>
    		</div>
    	</div>
    </div>	      

HTML;
        		}
        		if($type==3){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section"> <div class="loader loader-1">
		      <div class="loader-outter"></div>
		      <div class="loader-inner"></div>
		    </div></section>
HTML;
        		}
        		        		if($type==4){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section"> 		    <div class="loader loader-2">
		      <svg class="loader-star" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1">
		            <polygon points="29.8 0.3 22.8 21.8 0 21.8 18.5 35.2 11.5 56.7 29.8 43.4 48.2 56.7 41.2 35.1 59.6 21.8 36.8 21.8 " fill="#18ffff" />
		         </svg>
		      <div class="loader-circles"></div>
		    </div></section>
HTML;
        		}
        		        		if($type==5){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section"> 		    <div class="loader loader-18">
		      <div class="css-star star1"></div>
		      <div class="css-star star2"></div>
		      <div class="css-star star3"></div>
		      <div class="css-star star4"></div>
		      <div class="css-star star5"></div>
		      <div class="css-star star6"></div>
		      <div class="css-star star7"></div>
		      <div class="css-star star8"></div>
		    </div></section>
HTML;
        		}
        		        		if($type==6){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section"> 		    <div class="loader loader-7">
		      <div class="line line1"></div>
		      <div class="line line2"></div>
		      <div class="line line3"></div>
		    </div></section>
HTML;
        		}
        		        		if($type==7){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section"> 		    <div class="loader loader-21">
		      <div class="css-times times1"></div>
		      <div class="css-times times2"></div>
		      <div class="css-times times3"></div>
		    </div></section>
HTML;
        		}
        		        		if($type==8){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section"> 		    <div class="loader loader-17">
		      <div class="css-square square1"></div>
		      <div class="css-square square2"></div>
		      <div class="css-square square3"></div>
		      <div class="css-square square4"></div>
		      <div class="css-square square5"></div>
		      <div class="css-square square6"></div>
		      <div class="css-square square7"></div>
		      <div class="css-square square8"></div>
		    </div></section>
HTML;
        		}
        		        		if($type==9){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section"> 		    <div class="loader loader-4"></div></section>
HTML;
        		}
        		        		if($type==10){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section"> 		    <div class="loader loader-5">
		      <div class="loader-pacman"></div>
		    </div></section>
HTML;
        		}
        		        		if($type==11){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section">		    <div class="loader loader-14">
		      <svg class="loader-star star-small" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.172px" height="23.346px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon fill="#01579b" points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9  "></polygon>
		         </svg>
		      <svg class="loader-star star-big" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.172px" height="23.346px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon fill="#40c4ff" points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9  "></polygon>
		         </svg>
		    </div></section>
HTML;
        		}
        		        		if($type==12){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section"> 		    <div class="loader loader-12">
		      <svg class="loader-star star1" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="35px" height="35px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9" />
		         </svg>
		      <svg class="loader-star star2" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="35px" height="35px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9" />
		         </svg>
		      <svg class="loader-star star3" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="35px" height="35px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9" />
		         </svg>
		      <svg class="loader-star star4" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="35px" height="35px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9" />
		         </svg>
		      <svg class="loader-star star5" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="35px" height="35px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9" />
		         </svg>
		      <svg class="loader-star star6" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="35px" height="35px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9" />
		         </svg>
		    </div></section>
HTML;
        		}
        		        		if($type==13){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section">		    <div class="loader loader-6">
		      <div class="loader-inner"></div>
		    </div></section>
HTML;
        		}
        		        		if($type==14){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section"> 		    <div class="loader loader-13">
		      <div class="css-heart heart1"></div>
		      <div class="css-heart heart2"></div>
		      <div class="css-heart heart3"></div>
		      <div class="css-heart heart4"></div>
		    </div></section>
HTML;
        		}
        		        		if($type==15){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section">	    <div class="loader loader-20">
		      <div class="css-diamond"></div>
		    </div></section>
HTML;
        		}
        		        		if($type==16){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section">		    <div class="loader loader-9">
		      <svg class="loader-star star1" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.172px" height="23.346px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon fill="#c6ff00" points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9" />
		         </svg>
		      <svg class="loader-star star2" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.172px" height="23.346px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon fill="#c6ff00" points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9  " />
		         </svg>
		      <svg class="loader-star star3" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="23.172px" height="23.346px" viewBox="0 0 23.172 23.346" xml:space="preserve">
		            <polygon fill="#c6ff00" points="11.586,0 8.864,8.9 0,8.9 7.193,14.447 4.471,23.346 11.586,17.84 18.739,23.346 16.77,14.985 23.172,8.9 14.306,8.9  " />
		         </svg>
		    </div></section>
HTML;
        		}
        		        		if($type==17){
        	echo <<<HTML
        	<link href="/usr/plugins/QuietBeautify/assets/css/loader.css" rel="stylesheet">
        		    		  <section class="section">		    <div class="loader loader-3">
		      <div class="dot dot1"></div>
		      <div class="dot dot2"></div>
		      <div class="dot dot3"></div>
		    </div></section>
HTML;
        		}
        			if($type==18){
        	echo <<<HTML
        <style>
        #loading {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 99999;
    background-color: #FFFFFF;
    display: none;
}

#loading-center {
    width: 100%;
    position: absolute;
    top: 47%;
    left: 0;
    right: 0;
    margin: 0 auto;
    text-align: center;
}

#loading-center .dot {
    width: 24px;
    height: 24px;
    background: #3ac;
    border-radius: 100%;
    display: inline-block;
    animation: slide 1s infinite;
}

#loading-center .dot:nth-child(1) {
    animation-delay: 0.1s;
    background: #32aacc;
}

#loading-center .dot:nth-child(2) {
    animation-delay: 0.2s;
    background: #64aacc;
}

#loading-center .dot:nth-child(3) {
    animation-delay: 0.3s;
    background: #96aacc;
}

#loading-center .dot:nth-child(4) {
    animation-delay: 0.4s;
    background: #c8aacc;
}

#loading-center .dot:nth-child(5) {
    animation-delay: 0.5s;
    background: #faaacc;
}

@-moz-keyframes slide {
    0% {
        transform: scale(1);
    }

    50% {
        opacity: 0.3;
        transform: scale(2);
    }

    100% {
        transform: scale(1);
    }
}

@-webkit-keyframes slide {
    0% {
        transform: scale(1);
    }

    50% {
        opacity: 0.3;
        transform: scale(2);
    }

    100% {
        transform: scale(1);
    }
}

@-o-keyframes slide {
    0% {
        transform: scale(1);
    }

    50% {
        opacity: 0.3;
        transform: scale(2);
    }

    100% {
        transform: scale(1);
    }
}

@keyframes slide {
    0% {
        transform: scale(1);
    }

    50% {
        opacity: 0.3;
        transform: scale(2);
    }

    100% {
        transform: scale(1);
    }
}

        </style>
        <div id="loading" style="display: none;">
		<div id="loading-center">
			<div class="dot"></div>
			<div class="dot"></div>
			<div class="dot"></div>
			<div class="dot"></div>
			<div class="dot"></div>
		</div>
	</div>
HTML;
        		}
		 
        
    }
    	static function pointerStyle(){

		// 插件所在位置的路径信息
		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/';
	
		// 获取配置信息
		$type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->pointerStyle;
	
		if ($type == 0) {

		}else if($type==1){// 指针1
			echo '
			<style>
				body { cursor: url(' . $PluginPath . 'assets/img/normal.cur), default;  }
				a,button,img { cursor: url(' . $PluginPath . 'assets/img/link.cur), pointer !important; }
			</style>
			';
		}else if($type==2){// 指针2
			echo '
			<style>
				body { cursor: url(' . $PluginPath . 'assets/img/a1.cur), default; }
				a,button,img { cursor: url(' . $PluginPath . 'assets/img/a2.cur), pointer !important; }
			</style>
			';
		}else if($type==3){// 指针3
			echo '
			<style>
				body { cursor: url(' . $PluginPath . 'assets/img/b1.cur), default; }
				a,button,img { cursor: url(' . $PluginPath . 'assets/img/b2.cur), pointer !important; }
			</style>
			';
		}else if($type==4){// 指针4
			echo '
			<style>
				body { cursor: url(' . $PluginPath . 'assets/img/c1.cur), default; }
				a,button,img { cursor: url(' . $PluginPath . 'assets/img/c2.cur), pointer !important; }
			</style>
			';
		}else if($type==5){// 指针5
			echo '
			<style>
				body { cursor: url(' . $PluginPath . 'assets/img/d1.cur), default; }
				a,button,img { cursor: url(' . $PluginPath . 'assets/img/d2.cur), pointer !important; }
			</style>
			';
		}else if($type==6){// 指针5
			echo '
			<style>
				body { cursor: url(' . $PluginPath . 'assets/img/e.cur), default; }
				a,button,img { cursor: url(' . $PluginPath . 'assets/img/d2.cur), pointer !important; }
			</style>
			';
		}else if($type==7){// 指针5
			echo '
			<style>
				body { cursor: url(' . $PluginPath . 'assets/img/f.cur), default; }
				a,button,img { cursor: url(' . $PluginPath . 'assets/img/d2.cur), pointer !important; }
			</style>
			';
		}else if($type==8){// 指针5
			echo '
			<style>
				body { cursor: url(' . $PluginPath . 'assets/img/g.cur), default; }
				a,button,img { cursor: url(' . $PluginPath . 'assets/img/d2.cur), pointer !important; }
			</style>
			';
		}
	
	}

static function postduan(){
    $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->duan;
    		$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/assets/css/duan.css';
 if ($type) {
		   echo '<link type="text/css" rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" media="all"/>
<link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/5.13.1/css/all.min.css" rel="stylesheet">
<link href="' . $PluginPath .'" rel="stylesheet">';
 }
    }

static function linkput(){
        $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->link_config;
           if($type){
        
    }else{
        $type=array('null');
    };
        if(in_array('query',$type)){
            echo '<script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.min.js"></script>';
        }
        if(in_array('font',$type)){
            echo '<link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/5.15.2/css/all.min.css" rel="stylesheet">
            <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/5.15.2/css/fontawesome.min.css" rel="stylesheet">
            ';
        }
        if(in_array('layui',$type)){
            echo '<script src="https://cdn.bootcdn.net/ajax/libs/layui/2.5.7/layui.all.min.js"></script>';
        }
        if(in_array('animate',$type)){
            echo '<link href="https://cdn.bootcdn.net/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">';
        }
}

static function progresscss(){
    $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->loadingprogress;
 if ($type==1) {
		   echo '<style>.quiet_progress{
		           position: fixed;
    z-index: 9999;
    left: 0;
    bottom: -3px;
    height: 4px;
    border-radius: 1.5px;
    background: linear-gradient(to right, #4cd964, #5ac8fa, #007aff);
    transition: width 0.35s;
    top: 0;
    border-radius:20%;
		       
		   }</style>';
 }
    }
    static function cstextcss(){
    $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->cstext;
 if ($type!='') {
		   echo "<style>
		   $type {
    background-image       : linear-gradient(to left, orangered, orange, gold, lightgreen, cyan, dodgerblue, mediumpurple, hotpink, orangered);
    background-size        : 110vw;
    -webkit-background-clip: text;
    background-clip        : text;
    color                  : transparent !important;
    -webkit-animation      : rainbowan 60s linear infinite;
    animation              : rainbowan 60s linear infinite;
}

@-webkit-keyframes rainbowan {
    to {
        background-position: -2000vw;
    }
}

@keyframes rainbowan {
    to {
        background-position: -2000vw;
    }
}
		   </style>";
 }
    }
  static function wowhandle(){
        $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->wow;
        if(!empty($type)){
             echo '<script src="https://cdn.bootcdn.net/ajax/libs/wow/1.1.2/wow.min.js"></script>';
        }
       
  }  
}

?>