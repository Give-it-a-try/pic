<?php


 
class Quietfooter{
    // 网站运行时间
  
    
        static function loadingTrans(){
        $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->loadingStyle;
        if($type==0){
            
            
        }
        if($type==1){
            echo '<script>$(function(){ $("#PageLoading").fadeOut(530); });</script>';
            
        }
        if($type==18){
                        echo '<script>
document.onreadystatechange = function()
{ 
$("#loading").fadeIn(10);
　　 if(document.readyState == "complete"){
            $("#loading").fadeOut(500);
             
   　 }
}
</script>';
            
        }
        if($type!=1&&$type!=18){
            echo '<script>
document.onreadystatechange = function()
{
　　 if(document.readyState == "complete"){
            $(".section").eq(0).fadeOut(500);
             
   　 }
}
</script>';
        }
        
    }
 static function rightj(){
     $info = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->mouse_config;
    if($info){
        
    }else{
        $info=array('null');
    };
     if(in_array('yj',$info)){
         echo '<script>
                document.oncontextmenu=function(){
                    return false
                };
               
            </script>';
     }
     if(in_array('pbf12',$info)){
         echo ' <script>
                    document.onkeydown=function(){
                        if(window.event&&window.event.keyCode==123){
                            event.keyCode=0;
                            event.returnValue=false;
                            return false
                        }
                    };
                </script>';
     }
     
 }
 static function collapses(){
      $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->collapse;
      if($type){
            echo '<script>
	var OriginTitle = document.title; var titleTime; document.addEventListener("visibilitychange", function () { if (document.hidden) { document.title = "╭(°A°)╮ 页面崩溃啦 ~"; clearTimeout(titleTime) } else { document.title = "(ฅ>ω<*ฅ) 噫又好了~" + OriginTitle; titleTime = setTimeout(function () { document.title = OriginTitle }, 2000) } });
</script>';   
      }

 }
  static function hangcats(){
       $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->hangcat;
       if($type){
                echo '<script src="https://r3387.gitee.io/wenyu/assets/js/xuanguamiao/szgotop.js"></script>
<link href="https://r3387.gitee.io/wenyu/assets/js/xuanguamiao/szgotop.css" rel="stylesheet" />
<div class="back-to-top cd-top faa-float animated cd-is-visible" style="top: -999px;"></div>';
       }

 }
   static function copys(){
        $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->copyi;
        if($type){
              echo '<link href="https://cdn.bootcdn.net/ajax/libs/element-ui/2.9.2/theme-chalk/index.css" rel="stylesheet" />
<script src="https://r3387.gitee.io/wenyu/assets/eleui/js/vue.js"></script>
<script src="https://r3387.gitee.io/wenyu/assets/eleui/js/element.js"></script>
	<script>
    	document.addEventListener("copy",function(e){
			new Vue({
				data:function(){
					this.$notify({
						title:"复制成功",
						message:"若要转载请务必保留原文链接！",
						type:"success"
					});
					return{visible:false}
				}
			})
		})
    </script>';   
        }

 }
 static function typewritings(){
      $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->typewriting;
      if($type){
             echo '<script type="text/javascript" src="https://r3387.gitee.io/wenyu/assets/js/commentTyping.js"></script>';
      }
  
 }
  static function righticontype(){
      $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->righticon;
      if($type==1){
             echo '<div id="cc-myssl-id" style="position: fixed;right: 0;bottom: 0;width: 65px;height: 65px;z-index: 99;">
    <a><img src="https://ae04.alicdn.com/kf/Hab9cb5aa5889482c8dad4eee03b7f4e18.png" alt="" style="width:100%;height:100%"></a>
</div>';
      }
  
 }
   static function progresstype(){
      $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->loadingprogress;
      if($type==1){
             echo '<div class="quiet_progress" style="width: 100%;"></div>
             <script>
              {
      const t = ()=>{
          let t = $(window).scrollTop()
            , e = $(document).height()
            , o = $(window).height()
            , a = parseInt(t / (e - o) * 100);
          a <= 0 && (a = 0),
          a >= 100 && (a = 100),
          $(".quiet_progress").css("width", a + "%")
      }
      ;
      t(),
      $(window).on("scroll", ()=>t())
  }
             </script>
             ';
      }
  
 }
   static function clicktype(){
      $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->clickstyle;
      	$PluginPath = Helper::options()->pluginUrl.'/QuietBeautify/assets/js/cursor/';
      if($type==1){
             echo '<script src="'.$PluginPath.'cursor1.js"></script>';
      }
       if($type==2){
             echo '<script src="'.$PluginPath.'cursor2.js"></script>';
      }
       if($type==3){
             echo '<script src="'.$PluginPath.'cursor3.js"></script>';
      }
       if($type==4){
             echo '<script src="'.$PluginPath.'cursor4.js"></script>';
      }
       if($type==5){
             echo '<script src="'.$PluginPath.'cursor5.js"></script>';
      }
       if($type==6){
             echo '<script src="'.$PluginPath.'cursor6.js"></script>';
      }
       if($type==7){
             echo '<script src="'.$PluginPath.'cursor7.js"></script>';
      }
       if($type==8){
             echo '<script src="'.$PluginPath.'cursor8.js"></script>';
      }
       if($type==9){
             echo '<script src="'.$PluginPath.'cursor9.js"></script>';
      }
       if($type==10){
             echo '<script src="'.$PluginPath.'cursor10.js"></script>';
      }
       if($type==11){
             echo '<script src="'.$PluginPath.'cursor11.js"></script>';
      }
  
 }
 static function wowhandles(){
     $type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->wow;
     $wow_type = Typecho_Widget::widget('Widget_Options')->plugin('QuietBeautify')->wowlist;
     echo "<script>
     let wow_arr='$type'.split(',')
wow_arr.forEach(item=>{
let wow_item=item
console.log(wow_item)
   $(wow_item).addClass('wow $wow_type')
})
     </script>";
 }
}

?>