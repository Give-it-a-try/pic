
    <?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * Quiet个人美化小插件 >><a href="https://www.txmmp.cn/index.php/archives/27/" target="_blank" style="color:red;">查看更新</a>
 * 
 * @package QuietBeautify
 * @author Quiet
 * @version 2.9.1
 * @link https://www.txmmp.cn/
*
*/
     
include 'module/foot.min.php';
include 'module/header.min.php';
include 'module/form.min.php';
class QuietBeautify_Plugin implements Typecho_Plugin_Interface
{
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     * 
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->header = array(__CLASS__, 'header');
        Typecho_Plugin::factory('Widget_Archive')->footer = array(__CLASS__, 'footer');
        Typecho_Plugin::factory('Widget_Feedback')->comment = array('QuietBeautify_Plugin', 'qsm_send');
        Typecho_Plugin::factory('Widget_Feedback')->trackback = array('QuietBeautify_Plugin', 'qsm_send');
        Typecho_Plugin::factory('Widget_XmlRpc')->pingback = array('QuietBeautify_Plugin', 'qsm_send');
        Typecho_Plugin::factory('admin/write-post.php')->bottom = array('QuietBeautify_Plugin', 'button');
		Typecho_Plugin::factory('admin/write-page.php')->bottom = array('QuietBeautify_Plugin', 'button');
        return '插件已激活,请设置相关信息';
    }
        public static function button(){
       		?><style>.wmd-button-row {height: auto;}
.wmdp-span{background-image:none !important;background: none;font-size: large;text-align: center;color: #999999;font-family: serif;width: auto !important;}
</style>
		<script> 
          $(document).ready(function(){
          	$('#wmd-spacer4').after('<li class="wmd-button" id="wmd-jian-button" title="渐变note标签"><span class="wmdp-span">渐</span></li><li class="wmd-button" id="wmd-chang-button" title="常用note标签"><span class="wmdp-span">N</span></li>');

				function zeze(tag) {
					var myField;
					if (document.getElementById('text') && document.getElementById('text').type == 'textarea') {
						myField = document.getElementById('text');
					} else {
						return false;
					}
					if (document.selection) {
						myField.focus();
						sel = document.selection.createRange();
						sel.text = tag;
						myField.focus();
					}
					else if (myField.selectionStart || myField.selectionStart == '0') {
						var startPos = myField.selectionStart;
						var endPos = myField.selectionEnd;
						var cursorPos = startPos;
						myField.value = myField.value.substring(0, startPos)
						+ tag
						+ myField.value.substring(endPos, myField.value.length);
						cursorPos += tag.length;
						myField.focus();
						myField.selectionStart = cursorPos;
						myField.selectionEnd = cursorPos;
					} else {
						myField.value += tag;
						myField.focus();
					}
				}

                if($('#wmd-button-row').length !== 0){
                    $('#wmd-jian-button').click(function(){
						//var rs = "```\nyour code\n```\n";
						var rs="!!!\n<div class='tip'><p>默认情况<p></div>\n<div class='tip success'><p>success<p></div>\n<div class='tip error'><p>error<p></div>\n<div class='tip warning'><p>warning<p></div>\n!!!\n"
						zeze(rs);
					});
                       $('#wmd-chang-button').click(function(){
						//var rs = "```\nyour code\n```\n";
						var rs="!!!\n<div class='note info'>这里是 info 标签样式</div>\n<div class='note primary'>这里是 primary 标签样式</div>\n<div class='note warning'>这里是 warning 标签样式</div>\n<div class='note danger'>这里是 danger 标签样式</div>\n!!!\n"
						zeze(rs);
					});
                }
			});
</script>
<?php
		
}   
    
    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     * 
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate(){
        
          return "插件禁用成功";
    }
    
    /**
     * 获取插件配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
 ?>
       <div class="j-setting-contain">
    <link href="<?php echo Helper::options()->rootUrl ?>/usr/plugins/QuietBeautify/assets/css/quiet.css" rel="stylesheet" type="text/css" />
    <div>
        <div class="j-aside">
            <div class="logo">QuietBeautify 2.9.1</div>
            <ul class="j-setting-tab">
                <li data-current="j-setting-notice">插件说明</li>
                <li data-current="j-setting-global">Cuteen4.x美化</li>
                <li data-current="j-setting-general">通用主题美化</li>
            </ul>
        </div>
    </div>
    <div class="j-setting-notice"><div style="padding:10px;text-align:center;" width="100%"><p>版本更新：2.9.1</p><p>作者想说：随缘更新,如有问题请下方联系或反馈</p><p>联系作者：<a href="http://wpa.qq.com/msgrd?v=3&uin=630876811&site=qq&menu=yes">腾讯QQ</a> | <a href="mailto:630876811@qq.com">电子邮箱</a> | <a href="https://www.txmmp.cn">无人问津的小站</a></p> <a href="../usr/plugins/QuietBeautify/rewrite.php" target="_blank" style="font-size:20px;color:red;">一键让blog支持Emoji</a><?php echo QuietinputHead::updata('2.9.1');?></div></div>
       <script src="<?php echo Helper::options()->rootUrl ?>/usr/plugins/QuietBeautify/assets/js/quiet.js"></script>
  <?
//   引入第三方库

        $form->addInput(QuietinputHead::linkcss());
  
        // 圆角
        $radius = new Typecho_Widget_Helper_Form_Element_Radio(
            'radius',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('修改圆角边框(Cuteen4.x主题适配)'),
            _t('修改PC/Mobile端卡片样式为圆角</br>')
        );
        $radius->setAttribute('class', 'j-setting-content j-setting-global');
        $form->addInput($radius);
        // 手机端毛玻璃
         $ground_glass = new Typecho_Widget_Helper_Form_Element_Radio(
            'ground_glass',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('开启手机端毛玻璃(Cuteen4.x主题适配)'),
            _t('手机端开启毛玻璃效果</br>')
        );
        $ground_glass->setAttribute('class', 'j-setting-content j-setting-global');
        $form->addInput($ground_glass);
        // 修改手机端卡片样式
          $card = new Typecho_Widget_Helper_Form_Element_Radio(
            'card',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('修改手机端卡片样式(Cuteen4.x主题适配)'),
            _t('需要配合开启手机端毛玻璃效果</br>')
        );
        $card->setAttribute('class', 'j-setting-content j-setting-global');
        $form->addInput($card);
        // 修改触摸放大
          $trans = new Typecho_Widget_Helper_Form_Element_Radio(
            'trans',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('更改文章触摸特效(Cuteen4.x主题适配)'),
            _t('由缩略图特效改为全文章卡片特效</br>')
        );
        $trans->setAttribute('class', 'j-setting-content j-setting-global');
        $form->addInput($trans);
        // 修复music
        $music = new Typecho_Widget_Helper_Form_Element_Radio(
            'music',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('修复音乐播放器(Cuteen4.x主题适配)'),
            _t('修复播放器在手机端因歌名太长导致铺满宽度的问题</br>')
        );
        $music->setAttribute('class', 'j-setting-content j-setting-global');
        $form->addInput($music);
        
        $denglong = new Typecho_Widget_Helper_Form_Element_Radio(
            'denglong',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('顶部增加灯笼(主题通用适配)'),
            _t('修改了定位不固定,跟随下拉效果</br>')
        );
        $denglong->setAttribute('class', 'j-setting-content j-setting-general');
        $form->addInput($denglong);
        
        // 字体
        
            $fonts = new Typecho_Widget_Helper_Form_Element_Text(
                'fonts',
                NULL,
                Null,
                '请填入字体URL地址:',
                '请使用外链字体路径,不要使用过大的字体否则加载缓慢,记得套cdn嗷'
            );
            $fonts->setAttribute('class', 'j-setting-content j-setting-general');
            $form->addInput($fonts);
            
        // 字体抖动
        
        $fontShake= new Typecho_Widget_Helper_Form_Element_Text(
                'fontShake',
                NULL,
                Null,
                '抖动文字:',
                '抖动作用的元素，支持css选择器，请按照css样式class名或者id名输入，如.nav #header div.content等。支持多元素，请用半角逗号分隔'
            );
            $fontShake->setAttribute('class', 'j-setting-content j-setting-general');
            $form->addInput($fontShake);
            
            // 自定义右键菜单
             $rightMenu= new Typecho_Widget_Helper_Form_Element_Text(
                'rightMenu',
                NULL,
                Null,
                '自定义右键菜单:',
                '请填入友联/留言地址,使用半角逗号分隔,友联在前,留言在后'
            );
            $rightMenu->setAttribute('class', 'j-setting-content j-setting-general');
            $form->addInput($rightMenu);
            // 闪烁文字
            
            $fontflicker=new Typecho_Widget_Helper_Form_Element_Text(
                'fontflicker',
                NULL,
                Null,
                '五彩闪烁文字:',
                '闪烁作用的元素，支持css选择器，请按照css样式class名或者id名输入，如.nav #header div.content等。支持多元素，请用半角逗号分隔'
            );
            $fontflicker->setAttribute('class', 'j-setting-content j-setting-general');
            $form->addInput($fontflicker);
            
            // 弹框
            $tiplist = [
			'tip'      => '访问弹框',
			'lefttip'      => '左下角访问信息'
	    ];
	    $en_list = [
			// 'Particles',
		];
            $tip=new Typecho_Widget_Helper_Form_Element_Checkbox(
                'tip',
                $tiplist,
                $en_list,
                '弹框功能:',
                '给网站增加弹框还有左下角访问信息'
            );
            $tip->setAttribute('class', 'j-setting-content j-setting-general');
            $form->addInput($tip);
            
            // 配置时间啥的
            

        
                    // 鼠标
            
            $form->addInput(QuietinputHead::mouseStyle()->setAttribute('class', 'j-setting-content j-setting-general'));
            
            //msq支持emoji
        $duan = new Typecho_Widget_Helper_Form_Element_Radio(
            'duan',
            array(
                '0' => _t('否'),
                '1' => _t('是'),
            ),
            '0',
            _t('美化短代码'),
            _t('美化了ol序列因主题差异并未美化/hr分割线样式/编辑器新增2个美化note标签,会有提示-渐-N两个新增按钮</br>')
        );
            $duan->setAttribute('class', 'j-setting-content j-setting-general');
            $form->addInput($duan);  
            //屏蔽右键
            $form->addInput(QuietinputHead::right());
            //崩溃欺骗
            $form->addInput(QuietinputHead::collapse());
            //悬挂猫
            $form->addInput(QuietinputHead::hangcat());
            //复制提醒
            $form->addInput(QuietinputHead::copyi());
            //打字效果
            $form->addInput(QuietinputHead::typewriting());
                        // 加载样式
            $form->addInput(QuietinputHead::loadinglist());
            // 右下角图标
            $form->addInput(QuietinputHead::righticon());
            // 加载条
            $form->addInput(QuietinputHead::progress());
            //循环彩色
            $form->addInput(QuietinputHead::cstext());
            // 鼠标点击特效
            $form->addInput(QuietinputHead::clickstyle());
            // qmsg
             $form->addInput(QuietinputHead::send());
            //  wow
              $form->addInput(QuietinputHead::wow());
              $form->addInput(QuietinputHead::wowlist());
    }
    
    /**
     * 个人用户的配置面板
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */

        public static function personalConfig(Typecho_Widget_Helper_Form $form)
        {
        }

        public static function render()
        {
        }
    public static function header() {
        //  获取用户配置
          $PluginPath = Helper::options()->rootUrl . '/usr/plugins/QuietBeautify/assets/';
        $options = Helper::options();
        $radius = $options->plugin('QuietBeautify')->radius;
        $ground_glass=$options->plugin('QuietBeautify')->ground_glass;
        $card=$options->plugin('QuietBeautify')->card;
        $trans=$options->plugin('QuietBeautify')->trans;
        $music=$options->plugin('QuietBeautify')->music;
        $fonturl=$options->plugin('QuietBeautify')->fonts;
         $fontShake=$options->plugin('QuietBeautify')->fontShake;
         $rightMenu=$options->plugin('QuietBeautify')->rightMenu;
         Quietheader::loadingTrans();
         Quietheader::linkput();
         Quietheader::progresscss();
         Quietheader::cstextcss();
         Quietheader::wowhandle();
         	echo '<script type="text/javascript" src="' . $PluginPath . 'js/console.js"></script>';
        if ($radius) {
            echo '<style>
                .article.have-img.d-flex{
border-radius: 40px;
    box-shadow: 2px 4px 3px rgba(0,0,0,.2);
}
.carousel-inner{
    border-radius: 40px;
    box-shadow: 2px 4px 3px rgba(0,0,0,.2);
}
            </style>';
        }
        if ($ground_glass) {
           echo '<style>
                @media (max-width: 576px){
.article.have-img.d-flex div{
    display:flex;
}
.article-time{
    display:none !important;
}
    .article:not(.card-style) {
        color: #f8f9fa !important;
    }
}
            </style>';
        }
        if ($card) {
          echo '<style>
              @media screen and (max-width: 768px) {
 .article.have-img .blur-img img{
        filter: brightness(0.6) !important;
    }
              }
    @media (max-width: 576px) {
            .article.have-img .article-img ,.article.have-img.no-bg-img .article-img{
                display: none!important;
            }
                .article.have-img.flex-row-reverse .article-img,.article.have-img.no-bg-img.flex-row-reverse .article-img {
         display: none!important;
    }
        .article.have-img .article-ctx {
        margin: 0 auto;
    }
    }
            </style>';
        }
         if ($trans) {
          echo '<style>
             .article.have-img:hover {
     transform: scale(1.05) rotate(1deg);
}
.article.have-img{
    transition:all .4s linear;
}
            </style>';
        }
         if ($music) {
          echo '<style>
             #musicMobileBox {
max-width: 12.5rem;
}
            </style>';
        }
       if(!empty($fonturl)){
		    
    		echo '<style>@font-face{font-family:FontStyle;src:url("'.$fonturl.'");format("truetype");}*{font-family:FontStyle;}i{font-family:none;}@media only screen and (min-width:0px) and (max-width:767px){.index-banner{height:50vh!important;}}</style>';
		}
		if(!empty($fontShake)){
		   echo '<style>
		   @keyframes Pshake_Crazy{ 
    10%{transform:translate(-0.5px,-0.5px) rotate(0.5deg);} 
    20%{transform:translate(-0.5px,1.5px) rotate(0.5deg);} 
    30%{transform:translate(1.5px,0.5px) rotate(0.5deg);} 
    40%{transform:translate(1.5px,-0.5px) rotate(-0.5deg);} 
    50%{transform:translate(2.5px,1.5px) rotate(1.5deg);} 
    60%{transform:translate(-0.5px,-0.5px) rotate(-0.5deg);} 
    70%{transform:translate(-0.5px,2.5px) rotate(1.5deg);} 
    80%{transform:translate(2.5px,-1.5px) rotate(-0.5deg);} 
    90%{transform:translate(1.5px,-0.5px) rotate(1.5deg);} 
    0%,100%{transform:translate(0,0) rotate(0);} 
}
.Pshake{ 
    display: inline-block; 
    will-change: transform;
    -webkit-transform-origin: center center; 
    -ms-transform-origin: center center; 
        transform-origin: center center; 
    -webkit-animation: Pshake_Crazy 1s ease-in-out infinite; 
            animation: Pshake_Crazy 1s ease-in-out infinite; 
}
		   </style>'; 
		    
		}
		if(!empty($rightMenu)){
			   echo <<<HTML
			   <div class="usercm" style="left: 199px; top: 5px; display: none;">
    <ul>
        <li><a href="/" class="sy"><i class="fa fa-home fa-fw"></i><span>首页</span></a></li>
        <li><a href="javascript:void(0);" onclick="getSelect();"><i class="fa fa-copy fa-fw"></i><span>复制</span></a></li>
        <li><a href="javascript:void(0);" onclick="baiduSearch();"><i class="fa fa-search fa-fw"></i><span>搜索</span></a></li>
        <li><a href="javascript:history.go(1);"><i class="fa fa-arrow-right fa-fw"></i><span>前进</span></a></li>
        <li><a href="javascript:history.go(-1);"><i class="fa fa-arrow-left fa-fw"></i><span>后退</span></a></li>
        <li style="border-bottom:1px solid gray"><a href="javascript:window.location.reload();"><i class="fa fa-refresh fa-fw"></i><span>重载网页</span></a></li>
        <li><a href="/" class="lj"><i class="fa fa-meh-o fa-fw"></i><span>和我当邻居</span></a></li>  
           <li><a href="/" class="ly"><i class="fa fa-pencil-square-o fa-fw"></i><span>给我留言吧</span></a></li>
    </ul>
</div>
<style type="text/css">
    a {text-decoration: none;}
    div.usercm{background-repeat:no-repeat;background-position:center center;background-size:cover;background-color:#fff;font-size:13px!important;width:130px;-moz-box-shadow:1px 1px 3px rgba
(0,0,0,.3);box-shadow:0px 0px 15px #333;position:absolute;display:none;z-index:10000;opacity:0.9; border-radius: 8px;}
    div.usercm ul{list-style-type:none;list-style-position:outside;margin:0px;padding:0px;display:block}
    div.usercm ul li{margin:0px;padding:0px;line-height:35px;}
    div.usercm ul li a{color:#666;padding:0 15px;display:block}
    div.usercm ul li a:hover{color:#fff;background:rgba(170,222,18,0.88)}
    div.usercm ul li a i{margin-right:10px}
    a.disabled{color:#c8c8c8!important;cursor:not-allowed}
    a.disabled:hover{background-color:rgba(255,11,11,0)!important}
    div.usercm{background:#fff !important;}
    </style>
HTML;
		};
            Quietheader::pointerStyle();
     Quietheader::postduan();
    }
        public static function footer() {
        //  获取用户配置
        
          $PluginPath = Helper::options()->rootUrl . '/usr/plugins/QuietBeautify/assets/';
        $options = Helper::options();
        $denglong = $options->plugin('QuietBeautify')->denglong;
        $fontShake=$options->plugin('QuietBeautify')->fontShake;
        $rightMenu=$options->plugin('QuietBeautify')->rightMenu;
        $fontflicker=$options->plugin('QuietBeautify')->fontflicker;
        $tip=$options->plugin('QuietBeautify')->tip;
    
        Quietfooter::loadingTrans();
        Quietfooter::rightj();
        Quietfooter::collapses();
        Quietfooter::hangcats();
        Quietfooter::copys();
        Quietfooter::typewritings();
        Quietfooter::righticontype();
        Quietfooter::progresstype();
        Quietfooter::clicktype();
        Quietfooter::wowhandles();
        
        		if(!empty($fontShake)){
		   echo <<<HTML
  <script>
    var fontShake = '{$fontShake}'
    var arrfontShake = fontShake.split(',');
    arrfontShake.forEach(e => {
      $(e).addClass('Pshake')
    });
  </script>
HTML;
		    
		};
        if($denglong){
            echo <<<HTML
<!--春节代码-->
<div class="meiha"></div>
<style>
/** 梅花树 **/
.meiha {
        position: absolute;
        top: 0;
        right: 0;
        z-index: 999;
        width: 350px;/** PNG图宽度 **/
        height: 231px;/** PNG图高度 **/
        pointer-events: none;
        background: url('https://pic.rmb.bdstatic.com/bjh/6553c65e7a8431f0fcb0e084ffe95151.png');
}
</style>
<!-- 灯笼1 -->
<div class="deng-box">
        <div class="deng">
                <div class="xian"></div>
                <div class="deng-a">
                        <div class="deng-b"><div class="deng-t">节</div></div>
                </div>
                <div class="shui shui-a"><div class="shui-c"></div><div class="shui-b"></div></div>
        </div>
</div>

<!-- 灯笼2 -->
<div class="deng-box1">
        <div class="deng">
                <div class="xian"></div>
                <div class="deng-a">
                        <div class="deng-b"><div class="deng-t">春</div></div>
                </div>
                <div class="shui shui-a"><div class="shui-c"></div><div class="shui-b"></div></div>
        </div>
</div>
<style>
.deng-box {
        position: absolute;
        top: 117px;
        right: -20px;
        z-index: 9999;
        pointer-events: none;
}

.deng-box1 {
        position: absolute;
        top: 131px;
        right: 138px;
        z-index: 9999;
        pointer-events: none;
}
.deng-box1 .deng {
        position: relative;
        width: 120px;
        height: 90px;
        margin: 50px;
        background: #d8000f;
        background: rgba(216, 0, 15, 0.8);
        border-radius: 50% 50%;
        -webkit-transform-origin: 50% -100px;
        -webkit-animation: swing 5s infinite ease-in-out;
        box-shadow: -5px 5px 30px 4px rgba(252, 144, 61, 1);
}
.deng {
        position: relative;
        width: 120px;
        height: 90px;
        margin: 50px;
        background: #d8000f;
        background: rgba(216, 0, 15, 0.8);
        border-radius: 50% 50%;
        -webkit-transform-origin: 50% -100px;
        -webkit-animation: swing 3s infinite ease-in-out;
        box-shadow: -5px 5px 50px 4px rgba(250, 108, 0, 1);
}
.deng-a {
        width: 100px;
        height: 90px;
        background: #d8000f;
        background: rgba(216, 0, 15, 0.1);
        margin: 12px 8px 8px 10px;
        border-radius: 50% 50%;
        border: 2px solid #dc8f03;
}
.deng-b {
        width: 45px;
        height: 90px;
        background: #d8000f;
        background: rgba(216, 0, 15, 0.1);
        margin: -2px 8px 8px 26px;
        border-radius: 50% 50%;
        border: 2px solid #dc8f03;
}
.xian {
        position: absolute;
        top: -20px;
        left: 60px;
        width: 2px;
        height: 20px;
        background: #dc8f03;
}
.shui-a {
        position: relative;
        width: 5px;
        height: 20px;
        margin: -5px 0 0 59px;
        -webkit-animation: swing 4s infinite ease-in-out;
        -webkit-transform-origin: 50% -45px;
        background: #ffa500;
        border-radius: 0 0 5px 5px;
}
.shui-b {
        position: absolute;
        top: 14px;
        left: -2px;
        width: 10px;
        height: 10px;
        background: #dc8f03;
        border-radius: 50%;
}
.shui-c {
        position: absolute;
        top: 18px;
        left: -2px;
        width: 10px;
        height: 35px;
        background: #ffa500;
        border-radius: 0 0 0 5px;
}
.deng:before {
        position: absolute;
        top: -7px;
        left: 29px;
        height: 12px;
        width: 60px;
        content: " ";
        display: block;
        z-index: 999;
        border-radius: 5px 5px 0 0;
        border: solid 1px #dc8f03;
        background: #ffa500;
        background: linear-gradient(to right, #dc8f03, #ffa500, #dc8f03, #ffa500, #dc8f03);
}
.deng:after {
        position: absolute;
        bottom: -7px;
        left: 10px;
        height: 12px;
        width: 60px;
        content: " ";
        display: block;
        margin-left: 20px;
        border-radius: 0 0 5px 5px;
        border: solid 1px #dc8f03;
        background: #ffa500;
        background: linear-gradient(to right, #dc8f03, #ffa500, #dc8f03, #ffa500, #dc8f03);
}
.deng-t {
        font-family: 华文行楷,Arial,Lucida Grande,Tahoma,sans-serif;
        font-size: 3.2rem;
        color: #dc8f03;
        font-weight: bold;
        line-height: 85px;
        text-align: center;
}
.night .deng-t,
.night .deng-box,
.night .deng-box1 {
        background: transparent !important;
}
@-moz-keyframes swing {
        0% {
                -moz-transform: rotate(-10deg)
        }
        50% {
                -moz-transform: rotate(10deg)
        }

        100% {
                -moz-transform: rotate(-10deg)
        }
}
@-webkit-keyframes swing {
        0% {
                -webkit-transform: rotate(-10deg)
        }
        50% {
                -webkit-transform: rotate(10deg)
        }
        100% {
                -webkit-transform: rotate(-10deg)
        }
}
</style>
HTML;
        };
      if(!empty($rightMenu)){
          		   echo <<<HTML
<script>
$(function () {
        (function(a) {
        a.extend({
            mouseMoveShow: function(b) {
                var d = 0,
                    c = 0,
                    h = 0,
                    k = 0,
                    e = 0,
                    f = 0;
                a(window).mousemove(function(g) {
                    d = a(window).width();
                    c = a(window).height();
                    h = g.clientX;
                    k = g.clientY;
                    e = g.pageX;
                    f = g.pageY;
                    h + a(b).width() >= d && (e = e - a(b).width() - 5);
                    k + a(b).height() >= c && (f = f - a(b).height() - 5);
                    a("html").on({
                        contextmenu: function(c) {
                            3 == c.which && a(b).css({
                                left: e,
                                top: f
                            }).show()
                        },
                        click: function() {
                            a(b).hide()
                        }
                    })
                })
            },
            disabledContextMenu: function() {
                window.oncontextmenu = function() {
                    return !1
                }
            }
        })
    })(jQuery);
 

    $(function() {
        for (var a = navigator.userAgent, b = "Android;iPhone;SymbianOS;Windows Phone;iPad;iPod".split(";"), d = !0, c = 0; c < b.length; c++) if (0 < a.indexOf(b[c])) {
            d = !1;
            break
        }
        d && ($.mouseMoveShow(".usercm"), $.disabledContextMenu())
    }); 
      var rightMenustr='{$rightMenu}';
   var rightarr=rightMenustr.split(',')
   var homeurl=location.host
   
   $('.sy').attr('href','http://'+homeurl)
   $('.lj').attr('href',rightarr[0])
   $('.ly').attr('href',rightarr[1])
    });
  
    </script>
    <script>    function getSelect() {
        "" == (window.getSelection ? window.getSelection() : document.selection.createRange().text) ? layer.msg("啊噢...你没还没选择文字呢！") : document.execCommand("Copy")
    }
    function baiduSearch() {
        var a = window.getSelection ? window.getSelection() : document.selection.createRange().text;
        "" == a ? layer.msg("啊噢...你没还没选择文字呢！") : window.open("https://www.baidu.com/s?wd=" + a)
    }</script>
HTML;
      };
      if(!empty($fontflicker)){
          		   echo <<<HTML
<script>
  $(function(){
        var chakhsu = function (r,str) {
      function t() {
        return b[Math.floor(Math.random() * b.length)]
      }

      function e() {
        return String.fromCharCode(94 * Math.random() + 33)
      }

      function n(r) {
        for (var n = document.createDocumentFragment(), i = 0; r > i; i++) {
          var l = document.createElement("span");
          l.textContent = e(),
            l.style.color = t(),
            n.appendChild(l)
        }
        return n
      }

      function i() {
        var t = o[c.skillI];
        c.step ? c.step-- : (c.step = g, c.prefixP < l.length ? (c.prefixP >= 0 && (c.text += l[c.prefixP]), c.prefixP++) : "forward" === c.direction ? c.skillP < t.length ? (c.text += t[c.skillP], c.skillP++) : c.delay ? c.delay-- : (c.direction = "backward", c.delay = a) : c.skillP > 0 ? (c.text = c.text.slice(0, -1), c.skillP--) : (c.skillI = (c.skillI + 1) % o.length, c.direction = "forward")),
          r.textContent = c.text,
          r.appendChild(n(c.prefixP < l.length ? Math.min(s, s + c.prefixP) : Math.min(s, t.length - c.skillP))),
          setTimeout(i, d)
      }
      var l = "",
        o = [str,].map(function (r) {
          return r + ""
        }),
        a = 2,
        g = 1,
        s = 5,
        d = 75,
        b = ["rgb(110,64,170)", "rgb(150,61,179)", "rgb(191,60,175)", "rgb(228,65,157)", "rgb(254,75,131)", "rgb(255,94,99)", "rgb(255,120,71)", "rgb(251,150,51)", "rgb(226,183,47)", "rgb(198,214,60)", "rgb(175,240,91)", "rgb(127,246,88)", "rgb(82,246,103)", "rgb(48,239,130)", "rgb(29,223,163)", "rgb(26,199,194)", "rgb(35,171,216)", "rgb(54,140,225)", "rgb(76,110,219)", "rgb(96,84,200)"],
        c = {
          text: "",
          prefixP: -s,
          skillI: 0,
          skillP: 0,
          direction: "forward",
          delay: a,
          step: g
        };
      i()
    };
       var fontflicker = '{$fontflicker}'
    var fontflickerarr = fontflicker.split(',');
    fontflickerarr.forEach(e => {
       if($(e).length>0){
           $.each($(e),function(key,val){
chakhsu(val, val.innerText);
})
       }else{
           chakhsu($(e)[0], $(e).text());
       }
       
    });
  })
   
  </script>
HTML;
      };
          if($tip){
        
    }else{
        $tip=array('null');
    };
             if(in_array('tip',$tip)){
                 
  			if(in_array('lefttip',$tip)){
  			              echo '    <div id="fps" style="z-index:5;position:fixed;bottom:3px;left:3px;color:#2196F3;font-size:10px;-webkit-pointer-events: none;-moz-pointer-events: none;-ms-pointer-events: none;-o-pointer-events: none;pointer-events: none;"></div>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/gh/kaliisra/myblogstatic/kehuduan-js/fetch.min.js"></script>
    <script src="https://cdn.bootcdn.net/ajax/libs/layer/3.5.1/layer.min.js" type="text/javascript" charset="utf-8"></script>';
  			    	echo '<script type="text/javascript" src="' . $PluginPath . 'js/tip/tip.js"></script>';
  			    	return;
  			}
      };
      if(in_array('tip',$tip)){
          echo '    <div id="fps" style="z-index:5;position:fixed;bottom:3px;left:3px;color:#2196F3;font-size:10px;-webkit-pointer-events: none;-moz-pointer-events: none;-ms-pointer-events: none;-o-pointer-events: none;pointer-events: none;"></div>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/gh/kaliisra/myblogstatic/kehuduan-js/fetch.min.js"></script>
    <script src="https://cdn.bootcdn.net/ajax/libs/layer/3.5.1/layer.min.js" type="text/javascript" charset="utf-8"></script>';
  				echo '<script type="text/javascript" src="' . $PluginPath . 'js/tip/tip_a.js"></script>';
      };
       if(in_array('lefttip',$tip)){
                     echo '    <div id="fps" style="z-index:5;position:fixed;bottom:3px;left:3px;color:#2196F3;font-size:10px;-webkit-pointer-events: none;-moz-pointer-events: none;-ms-pointer-events: none;-o-pointer-events: none;pointer-events: none;"></div>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/gh/kaliisra/myblogstatic/kehuduan-js/fetch.min.js"></script>
    <script src="https://cdn.bootcdn.net/ajax/libs/layer/3.5.1/layer.min.js" type="text/javascript" charset="utf-8"></script>';
  				echo '<script type="text/javascript" src="' . $PluginPath . 'js/tip/tip_b.js"></script>';
      };

    }
    public static function qsm_send($comment, $post){
            $options = Typecho_Widget::widget('Widget_Options');

        $key = $options->plugin('QuietBeautify')->send;
            $title=$post->title;
            $comments=$comment['text'];
            $author=$comment['author'];
            $created_at= date('Y-m-d H:i:s', $comment['created']);
            $url=$post->permalink;
            
  $postdata = "文章标题: $title
评论内容: $comments
评论人: $author
评论时间: $created_at
地址: $url";
        $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://qmsg.zendee.cn/send/'.$key,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'msg='.$postdata,
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
        return $comment;
    }
}
?>