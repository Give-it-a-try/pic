<?php
$file_path = '../../../config.inc.php';
if (file_exists($file_path)) {
    $str = file_get_contents($file_path);//将整个文件内容读入到一个字符串中
    $str = str_replace("'utf8'", "'utf8mb4'", $str);
    file_put_contents($file_path, $str);
    echo '<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"><meta http-equiv="X-UA-Compatible" content="IE=edge"><title>emoji引导</title><style type="text/css">html,body{height:100%;margin:0;padding:0}body{background-image:linear-gradient(120deg,#84fab0 0,#8fd3f4 100%)}div{text-align:center;padding-top:25vh;font-size:24px;color: #fff;}a{text-decoration:none;border:2px solid #ff3030;padding:10px 20px;border-radius:10px;font-size:24px;color:white;background:#ff3030}</style></head><body><div>处理完成，请关闭当前窗口</div></body></html>';
}else{
    echo '<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"><meta http-equiv="X-UA-Compatible" content="IE=edge"><title>emoji引导</title><style type="text/css">html,body{height:100%;margin:0;padding:0}body{background-image:linear-gradient(120deg,#84fab0 0,#8fd3f4 100%)}div{text-align:center;padding-top:25vh;font-size:24px;color: #fff;}a{text-decoration:none;border:2px solid #ff3030;padding:10px 20px;border-radius:10px;font-size:24px;color:white;background:#ff3030}</style></head><body><div>处理失败</div></body></html>';
}
exit();
?>